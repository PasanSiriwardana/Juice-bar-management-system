package com.example.juiceInvort.repository;

import com.example.juiceInvort.entity.Juice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JuiceRepository extends JpaRepository<Juice, Long> {
}
