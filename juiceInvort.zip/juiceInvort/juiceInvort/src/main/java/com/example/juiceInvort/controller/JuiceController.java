package com.example.juiceInvort.controller;

import com.example.juiceInvort.dto.JuiceDto;
import com.example.juiceInvort.service.JuiceService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@AllArgsConstructor
@RequestMapping("/api/juice")
public class JuiceController {

    private JuiceService juiceService;

    //Build Add juice Rest

    @PostMapping
    public ResponseEntity<JuiceDto> createJuice(@RequestBody JuiceDto juiceDto){

        JuiceDto savedCustemer = juiceService.createJuice(juiceDto);
        return new ResponseEntity<>(savedCustemer, HttpStatus.CREATED);

    }
    //build get juice(show data)
    @GetMapping("{jusId}")
    public  ResponseEntity<JuiceDto> getJuiceById(@PathVariable("jusId") Long juiceId){

        JuiceDto juiceDto = juiceService.getJuiceById(juiceId);
        return ResponseEntity.ok(juiceDto);

    }

    //Build set All juicew Details
    @GetMapping
    public ResponseEntity<List<JuiceDto>> getAllJuice(){

        List<JuiceDto> juice = juiceService.getAllJuice();

        return ResponseEntity.ok(juice);

    }

    //build update Juice Data

    @PutMapping("{jusId}")
    public  ResponseEntity<JuiceDto> updateJuice(@PathVariable("jusId") Long juiceId, @RequestBody JuiceDto updatedJuice){

        JuiceDto juiceDto = juiceService.updateJuice(juiceId, updatedJuice);
        return ResponseEntity.ok(juiceDto);
    }

    @DeleteMapping("{jusId}")
    public ResponseEntity<String> deleteJuice(@PathVariable("jusId") Long juiceId){
        juiceService.deleteJuice(juiceId);

        return ResponseEntity.ok("Deleted Juice Data : " + juiceId);
    }
}
