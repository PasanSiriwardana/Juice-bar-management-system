package com.example.juiceInvort.service.impl;

import com.example.juiceInvort.dto.JuiceDto;
import com.example.juiceInvort.entity.Juice;
import com.example.juiceInvort.exception.JuiceNotFoundException;
import com.example.juiceInvort.mapper.JuiceMapper;
import com.example.juiceInvort.repository.JuiceRepository;
import com.example.juiceInvort.service.JuiceService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class JuiceServiceImpl implements JuiceService {

    private JuiceRepository juiceRepository;

    @Override
    public JuiceDto createJuice(JuiceDto juiceDto) {

        Juice juice = JuiceMapper.mapToJuice(juiceDto);
        Juice savedJuice = juiceRepository.save(juice);
        return JuiceMapper.mapJuiceDto(savedJuice);
    }

    @Override
    public JuiceDto getJuiceById(Long juiceId) {
        Juice juice =  juiceRepository.findById(juiceId)
                .orElseThrow(()-> new JuiceNotFoundException("Enter Valid Juice Id : " + juiceId));

        return JuiceMapper.mapJuiceDto(juice);
    }

    @Override
    public List<JuiceDto> getAllJuice() {

        List<Juice> juices = juiceRepository.findAll();

         return juices.stream().map((juice)-> JuiceMapper.mapJuiceDto(juice)).collect(Collectors.toList());
    }

    @Override
    public JuiceDto updateJuice(Long juiceId, JuiceDto updateJuice) {

        Juice juice = juiceRepository.findById(juiceId).orElseThrow(
                ()-> new JuiceNotFoundException("Enter Valid Juice Id : " + juiceId )
        );

        juice.setJusName(updateJuice.getJusName());
        juice.setJusQuantity(updateJuice.getJusQuantity());

        Juice updateJuiceObj = juiceRepository.save(juice);
        return JuiceMapper.mapJuiceDto((updateJuiceObj));

    }

    @Override
    public void deleteJuice(Long juiceId) {
        Juice juice = juiceRepository.findById(juiceId).orElseThrow(
                ()-> new JuiceNotFoundException("Enter Valid Juice Id : " + juiceId )
        );

        juiceRepository.deleteById(juiceId);
    }


}
