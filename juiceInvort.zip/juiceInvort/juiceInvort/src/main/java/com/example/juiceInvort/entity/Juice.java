package com.example.juiceInvort.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "juiceDB")


public class Juice {

    @Id
    private Long jusId;

    @Column(name = "JuiceName")
    private String jusName;

    @Column(name = "JuiceQuantity")
    private Long jusQuantity;



}
