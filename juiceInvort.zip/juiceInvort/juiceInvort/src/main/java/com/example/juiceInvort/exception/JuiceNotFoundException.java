package com.example.juiceInvort.exception;

public class JuiceNotFoundException extends RuntimeException{

    public JuiceNotFoundException(String message){
        super (message);
    }
}
