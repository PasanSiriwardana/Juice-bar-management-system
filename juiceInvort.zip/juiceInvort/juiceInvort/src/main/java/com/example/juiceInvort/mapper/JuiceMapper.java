package com.example.juiceInvort.mapper;

import com.example.juiceInvort.dto.JuiceDto;
import com.example.juiceInvort.entity.Juice;

public class JuiceMapper {

    public static JuiceDto mapJuiceDto(Juice juice) {
        return new JuiceDto(
                juice.getJusId(),
                juice.getJusName(),
                juice.getJusQuantity()

        );
    }
    public static Juice mapToJuice(JuiceDto juiceDto){
        return new Juice(
                juiceDto.getJusId(),
                juiceDto.getJusName(),
                juiceDto.getJusQuantity()

        );
    }
}
