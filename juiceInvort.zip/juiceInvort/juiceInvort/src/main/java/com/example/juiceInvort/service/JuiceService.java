package com.example.juiceInvort.service;

import com.example.juiceInvort.dto.JuiceDto;
import com.example.juiceInvort.entity.Juice;

import java.util.List;

public interface JuiceService {

    JuiceDto createJuice( JuiceDto juiceDto);
    JuiceDto getJuiceById(Long juiceId);

    List<JuiceDto> getAllJuice();

    JuiceDto updateJuice (Long juiceId, JuiceDto updateJuice);

    void deleteJuice(Long juiceId);


}
