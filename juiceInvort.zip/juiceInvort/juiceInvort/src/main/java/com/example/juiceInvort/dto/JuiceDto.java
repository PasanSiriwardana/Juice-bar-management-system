package com.example.juiceInvort.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor


public class JuiceDto {
    private Long jusId;
    private String jusName;

    private Long jusQuantity;

}
